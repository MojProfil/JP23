module edunova02 {
	requires java.desktop;
}