package edunova.zadaci;

public class Zadatak8 {
	
	//. Napiši program koji određuje površinu trokuta zadanih stranica.

}
