package edunova.zadaci;

public class Zadatak7 {
	
	// Program od korisnika unosi slovo
	// u slučaju slova A ispisuje 1. mjesto
	// pa sve do slova E gdje ispisuje 5. mjesto

}
