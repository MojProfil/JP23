package edunova.zadaci;

public class Zadatak2 {
	
	public static void main(String[] args) {
		int i=2,j=1,t;
		
		i+=j; 
		t=j+i++; 
		j+=1; 
		System.out.println(i+j+t);
		// bez izvođenja dobiti rezultat koji se provjeri izvođenjem
	}

}
