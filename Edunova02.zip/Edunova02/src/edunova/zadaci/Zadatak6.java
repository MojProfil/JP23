package edunova.zadaci;

public class Zadatak6 {
	
	// Korisnik unosi 2 broja. 
	// Ukoliko je produkt ta dva broja paran broj
	// ispisuje razliku unesinih brojeva
	// inače ispisuje cijeli dio kvocjenta prvog i drugog broja

}
