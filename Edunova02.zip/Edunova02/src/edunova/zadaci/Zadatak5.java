package edunova.zadaci;

public class Zadatak5 {
	
	// Korisnik unosi cijeli broj
	// Ako je paran broj unesen ispiši Osijek
	// Ako je neparan broj unesen ispiši Zagreb
	
	// koristiti inline if

}
