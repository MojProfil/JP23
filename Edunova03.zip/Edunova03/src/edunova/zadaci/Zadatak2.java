package edunova.zadaci;

public class Zadatak2 {
	
	// Program unosi dva cijela broja.
	// Program ispisuje OK ako je zbroj svih parnih brojeva
	// između ta dva cijela broja
	// veći od 1000 

}
