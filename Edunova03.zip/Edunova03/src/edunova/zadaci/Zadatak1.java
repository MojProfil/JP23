package edunova.zadaci;

public class Zadatak1 {

	//Program ispisuje sve brojeve od 20 do 200
	
	// program ispisuje sve parne brojeve od 1 do 57
	
	//program ispisuje sve brojeve od 100 do 1
	
	//program ispisuje sve neparne brojeve od 100 do 21
}
